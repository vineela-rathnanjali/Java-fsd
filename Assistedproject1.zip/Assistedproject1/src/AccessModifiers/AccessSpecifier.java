package AccessModifiers;
	public class AccessSpecifier {
	    public String publicField = "This is a public field";

	    public AccessSpecifier() {
	        System.out.println("This is a public constructor");
	    }

	    public void publicMethod() {
	        System.out.println("This is a public method");
	    }
	    
	    public static void main(String[] args) {
	        AccessSpecifier example = new AccessSpecifier();
	        System.out.println("Public field: " + example.publicField);
	        example.publicMethod();

	        OtherClass other = new OtherClass();
	        other.demoAccessSpecifier();
	    }
	}

	class OtherClass {
	    String packagePrivateField = "This is a package-private (default) field";

	    OtherClass() {
	        System.out.println("This is a package-private (default) constructor");
	    }

	    private void privateMethod() {
	        System.out.println("This is a private method");
	    }

	    protected void protectedMethod() {
	        System.out.println("This is a protected method");
	    }

	    void packagePrivateMethod() {
	        System.out.println("This is a package-private (default) method");
	    }

	    void demoAccessSpecifier() {
	        System.out.println("Package-private field: " + packagePrivateField);
	        System.out.println("Calling package-private method...");
	        packagePrivateMethod();

	        System.out.println("Calling private method...");
	        privateMethod();

	        System.out.println("Calling protected method...");
	        protectedMethod();
	    }
	}
