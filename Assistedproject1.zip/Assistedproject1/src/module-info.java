/**
 * 
 */
/**
 * 
 */
module Assistedproject1 {
}