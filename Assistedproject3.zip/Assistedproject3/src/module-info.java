/**
 * 
 */
/**
 * 
 */
module Assistedproject3 {
}