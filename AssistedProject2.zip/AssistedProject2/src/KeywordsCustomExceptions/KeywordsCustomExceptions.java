package KeywordsCustomExceptions;
	class CustomException extends Exception {
	    public CustomException(String message) {
	        super(message);
	    }
	}
	public class KeywordsCustomExceptions {
	    public static void main(String[] args) {
	        try {
	            throw new CustomException("This is a custom exception.");

	        } catch (CustomException e) {
	            System.out.println("Caught custom exception: " + e.getMessage());

	        } catch (ArithmeticException e) {
	            System.out.println("Caught arithmetic exception: " + e.getMessage());

	        } catch (Exception e) {
	            System.out.println("Caught general exception: " + e.getMessage());

	        } finally {
	            System.out.println("This block will always execute.");
	        }

	        try {
	           performOperation(5, 0);
	        } catch (ArithmeticException e) {
	            System.out.println("Caught arithmetic exception in performOperation: " + e.getMessage());
	        }
	    }

	    public static void performOperation(int a, int b) throws ArithmeticException {
	        if (b == 0) {
	            throw new ArithmeticException("Division by zero.");
	        }
	        int result = a / b;
	        System.out.println("Result of the operation: " + result);
	    }
	}
