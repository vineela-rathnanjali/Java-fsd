package oopsEIAP;
	// Define a class 'Person' to represent a person
	class Person {
	    // Attributes (encapsulation)
	    private String name;
	    private int age;

	    // Constructor
	    public Person(String name, int age) {
	        this.name = name;
	        this.age = age;
	    }

	    // Methods (abstraction)
	    public void introduce() {
	        System.out.println("Hello, my name is " + name + " and I am " + age + " years old.");
	    }
	}

	// Define a subclass 'Student' that inherits from 'Person'
	class Student extends Person {
	    private String studentId;

	    // Constructor
	    public Student(String name, int age, String studentId) {
	        super(name, age);
	        this.studentId = studentId;
	    }

	    // Method overriding (polymorphism)
	    @Override
	    public void introduce() {
	        System.out.println("I am a student. My name is " + getName() + ", I am " + getAge() +
	                " years old, and my student ID is " + studentId + ".");
	    }
	}

	public class OOPDemo {
	    public static void main(String[] args) {
	        // Creating objects of 'Person' and 'Student' classes
	        Person person1 = new Person("Alice", 30);
	        Student student1 = new Student("Bob", 20, "S12345");

	        // Using objects and demonstrating encapsulation, abstraction, and polymorphism
	        person1.introduce();  // Output: Hello, my name is Alice and I am 30 years old.
	        student1.introduce(); // Output: I am a student. My name is Bob, I am 20 years old, and my student ID is S12345.
	    }
	}
